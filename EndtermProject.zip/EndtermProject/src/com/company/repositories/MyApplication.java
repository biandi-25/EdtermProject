package com.company.repositories;

public class MyApplication {
}
